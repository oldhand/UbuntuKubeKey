.. _ansible_collections.kubernetes.core.docsite.k8s_scenarios:

********************************
Ansible for Kubernetes Scenarios
********************************

These scenarios teach you how to accomplish common Kubernetes tasks using Ansible. To get started, please select the task you want to accomplish.

.. toctree::
   :maxdepth: 1

   scenario_k8s_object